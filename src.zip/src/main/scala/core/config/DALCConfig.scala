package core.config

/**
 * User: nowi
 * Date: 11.03.2010
 * Time: 11:26:08
 */
import core._
import containers.CNFClauseStore
import core.reduction._
import core.rewriting.{Substitutor, VariableRewriter}
import ordering.{CustomConferencePartitionedPrecedence,ALCLPOComparator}
import org.neo4j.kernel.EmbeddedGraphDatabase
import recording.{NaiveClauseRecorder, Neo4JRecorder}
import resolution.{DALCUniqueLiteralResolver, DALCResolver}
import selection.{DALCRSelector}

object DALCConfig {
  // empty initial clauses
  lazy val initialClauses = CNFClauseStore()

  lazy val tautologyDeleter = new TautologyDeleter()
  lazy val variableRewriter = new VariableRewriter()
  lazy val subsumptionDeleter = new SubsumptionDeleter(this)
  lazy val standardizer = new Standardizer(this)
  lazy val unificator = new Unificator(this)
  lazy val substitutor = new Substitutor(this)
  lazy val factorizer = new OrderedFactorizer(this)
  lazy val resolver = new DALCResolver(this)
  lazy val subsumptionStrategy = new StillmannSubsumer(this)
  lazy val uniqueLiteralResolver = new DALCUniqueLiteralResolver(this)
  lazy val inferenceRecorder = new NaiveClauseRecorder

  // storage

  // one graph database per reasoning node
  lazy val neo4JGraphBasePath : String = "/workspace/DIRE/DIRE/logs/graph/clauses"

  // ordered resolution needs comparator and selection too
  lazy val precedence = new CustomConferencePartitionedPrecedence
  lazy val literalComparator = new ALCLPOComparator(this)
  lazy val selector = new DALCRSelector

  // settings
  val recordProofSteps = true
  val removeDuplicates = false
  val useLightesClauseHeuristic = true
  val usableBackSubsumption = false
  val forwardSubsumption = true
  val dropSeenClauses = false
  val useIndexing = true

  // set a time limit
  val timeLimit: Long = (10 * 60 * 1000) // 10 min
}