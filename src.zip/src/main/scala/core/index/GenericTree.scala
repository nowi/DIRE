package core.index

/**
 * User: nowi
 * Date: 31.03.2010
 * Time: 19:43:16
 */

/* Internally, a map is a tree node; there is no wrapper. */

abstract class GenericTree[K, V]  {
  //In fact, the standard prelude already defines just such an implicit:
  //intWrapper.
  // modWith: Helper method; top node could be red.
  private[map] def modWith (k : K, f : (K, Option[V]) => Option[V]) : GenericTree[K,V]

  // modifiedWith: Insert, update and delete all in one.
  def modifiedWith (k : K, f : (K, Option[V]) => Option[V]) : GenericTree[K,V] =
    modWith(k,f)

  // get: Retrieve a value for a key.
  def get(k : K) : Option[V]

  // insert: Insert a value at a key.
  def insert (k : K, v : V) = modifiedWith (k, (_,_) => Some(v))

  // remove: Delete a key.
  def remove (k : K) = modifiedWith (k, (_,_) => None)
}


// A leaf node.
private case class L[K, V]  extends GenericTree[K,V]  {
  def get(k : K) : Option[V] = None

  private[map] def modWith (k : K, f : (K, Option[V]) => Option[V]) : GenericTree[K,V] = {
    T(R, this, k, f(k,None), this)
  }
}


// A tree node.
private case class T[K, V](l : GenericTree[K,V], k : K, v : Option[V], r : GenericTree[K,V])  extends GenericTree[K,V] {
  def get(k : K) : Option[V] = {
    if (k < this.k) l.get(k) else
    if (k > this.k) r.get(k) else
    v
  }

  private[map] def modWith (k : K, f : (K, Option[V]) => Option[V]) : GenericTree[K,V] = {
    (T(c,l,k,f(this.k,this.v),r))
  }
}


// A helper object.
object GenericTree {

  // empty: Converts an orderable type into an empty RBMap.
  def empty[K <: Ordered[K], V] : GenericTree[K,V] = L()((k : K) => k)

  // apply: Assumes an implicit conversion.
  def apply[K, V](args : (K,V)*) : GenericTree[K,V] = {
    var currentMap : GenericTree[K,V] = L()
    for ((k,v) <- args) {
      currentMap = currentMap.insert(k,v)
    }
    currentMap
  }
}
