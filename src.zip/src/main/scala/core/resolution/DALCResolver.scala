package core.resolution


import collection.immutable.EmptyMap
import containers.{MatchingClausesRetrieval, CNFClauseStore, ClauseStorage}
import domain.fol.ast._
import helpers.Logging
import ordering.{ALCLPOComparator, LiteralComparison}
import ClauseRecording
import reduction.Factoring
import rewriting.Substitution
import selection.{DALCRSelector, LiteralSelection}
import sun.reflect.generics.reflectiveObjects.NotImplementedException

/**
 * User: nowi
 * Date: 01.03.2010
 * Time: 15:32:54
 */

class DALCResolver(env: {val inferenceRecorder: ClauseRecording; val useIndexing: Boolean; val recordProofSteps: Boolean; val unificator: Unify; val factorizer: Factoring; val standardizer: Standardizing; val substitutor: Substitution; val selector: LiteralSelection; val literalComparator: LiteralComparison; val uniqueLiteralResolver: UniqueLiteralResolution}) extends Resolution with Logging {
  val unificator = env.unificator
  val factorizer = env.factorizer
  val standardizer = env.standardizer
  val substitutor = env.substitutor
  val selector = env.selector
  val literalComparator = env.literalComparator
  val recordProofSteps = env.recordProofSteps
  val useIndexing = env.useIndexing
  val uniqueLiteralResolver = env.uniqueLiteralResolver
  val inferenceRecorder = env.inferenceRecorder
  // some invariants , dalc resolver needs compatible selection and comperator

  //require(literalComparator.isInstanceOf[ALCLPOComparator])

  //require(selector.isInstanceOf[ALCRSelector])



  override def resolve(a: FOLClause, b: ClauseStorage) = {
    b match {
      case store: MatchingClausesRetrieval if (useIndexing) => resolveWithMatchingIndex(a, store)
      case _ => resolveWithoutIndex(a, b)
    }


  }

  private def resolveWithoutIndex(a: FOLClause, b: ClauseStorage) = {
    throw new NotImplementedException


  }

  private def resolveWithMatchingIndex(a: FOLClause, b: MatchingClausesRetrieval): Iterable[ResolutionResult] = {
    log.trace("Resolving with MatchingIndexSupport %s with %s", a, b)


    // get the matching claueses , we only need matching clauses for the unique resolvable literal

    a.uniqueResolvableLit(uniqueLiteralResolver) match {
      case Some(urlit) => {

        val matchingClauses =
        b.getMatchingClauses(urlit).getOrElse(Set()) ++
                b.getMatchingClauses(Negation(urlit)).getOrElse(Set()) - a

        matchingClauses match {
          case clauses: Set[FOLClause] if (clauses.isEmpty) => { // shortcut
            // no matching clauses
            Nil
          }
          case clauses: Set[FOLClause] => { // merge all successfull resolutions

            var parents = Set[FOLClause]()
            val results = clauses.map(resolve(a, _))
            val successes = results.filter {_.isInstanceOf[SuccessfullResolution]}

            val resolvents = successes.map {
              case SuccessfullResolution(resolvents, parent1, parent2) => { // extract the resolved clauses
                parents ++= Set(parent1, parent2)
                resolvents
              }

            }


            if (!successes.isEmpty) {
              // get the first success
              val anySuccess = successes.toList.head.asInstanceOf[SuccessfullResolution]
              successes
            } else {
              Nil
              //Failure(a, None)
            }


          }

        }


      }

      case None => {
        // there is no unique resolvabel literal
        Nil
        //Failure(a, None)

      }
    }


  }


  /**
   * Binary Distribtued ALC Resolution method as described in Paper :
   * SCHLICHT und Stuckenschmidt. Distributed resolution for ALC. Proceedings of the International … (2008)
   *
   *
   */

  override def resolve(a: FOLClause, b: FOLClause): ResolutionResult = {
    // optimisation with regards to FOL resolution :
    // Analysing all possible types of inferences among these clause will reveal that
    // in all cases the resolvable literals can be determined prior to substitution.
    if (a == b) FailedResolution(a, Some(b))
    log.trace("Resolving the Clauses %s,%s", a, b)

    // TODO CEHCK THIS
    //val (aStand, bStand, renamings) = standardizer.standardizeApart(a, b)

    // filter out option clauses
    val conclusions: Set[FOLClause] =
    (Set(doResolve(a, b),doResolve(b,a))) // // TODO IMPORTANT CHECK THIS !!! resolve both ways
            .filter(_.isDefined) // filter out options
            .map({_.get}) // convert Option[Map] --> Map


    if (conclusions.isEmpty)
      FailedResolution(a, Some(b))
    else
      SuccessfullResolution(conclusions, a, b)


  }


  private def doResolve(a: FOLClause, b: FOLClause): Option[FOLClause] = {
    // check the resolvability

    // standardise both clauses
    val (aStand, bStand, renamings) = standardizer.standardizeApart(a, b)
    // first determine the resolvable literal
    val aURLit: Option[FOLNode] = aStand.uniqueResolvableLit(uniqueLiteralResolver)

    // ouptut the uniqueResolvableLiteral
    log.debug("URLit for clauses : %s , %s ===> %s", a, b, aURLit)

    val resolved: Option[FOLClause] = aURLit match {
      case Some(aUrlit) => {
        bStand.uniqueResolvableLit(uniqueLiteralResolver) match {
          case Some(bUrlit) => {
            // resolve !

            if (aUrlit.negative && bUrlit.positive || aUrlit.positive && bUrlit.negative) {
              {
                // standardise the urlits
                //val (aStandUrlit, bStandUrlit, renamingsUrlits) = standardizer.standardizeApart(aUrlit, bUrlit)



                // unify
                log.debug("Resolving on literals %s and %s", aUrlit, bUrlit)

                unificator.unify(aUrlit, bUrlit) match {
                  case Some(mgu) => {

                    // perform the resolution
                    log.debug("MGU for Literal : %s and Literal %s is %s", aUrlit, bUrlit, mgu)
                    //            Let S_1 and S_2 be two clauses with no variables in common, let S_1 contain a positive literal L_1, S_2 contain a negative literal L_2, and let eta be the most general unifier of L_1 and L_2. Then
                    //(S_1eta-L_1eta) union (S_2eta-L_2eta)
                    // substition function
                    // s(lit) <=> σ
                    val sC = (clause: FOLClause) => substitutor.substitute(Some(mgu), clause)
                    val sN = (node: FOLNode) => substitutor.substitute(Some(mgu), node)


                    val S1 = sC(aStand)
                    val aPosS = sN(aUrlit)
                    val S2 = sC(bStand)
                    val bNegS = sN(bUrlit)

                    log.debug("a : %s", S1)
                    log.debug("aPos : %s", aPosS)
                    log.debug("S2 : %s", S2)
                    log.debug("bNegS : %s", bNegS)



                    var resolvent: FOLClause = renamings match {
                      case map if (map.isEmpty) => ALCDClause((S1 - aPosS) ++ (S2 - bNegS))
                      case _ => substitutor.substitute(Some(renamings), ALCDClause((S1 - aPosS) ++ (S2 - bNegS)))
                    }

                    Some(resolvent)

                  }

                  case None => {
                    // cannot be unified
                    None
                  }
                }


              }

            } else {
              None
            }


          }
          case None => {
            None

          }
        }


      }
      case None => {
        None
      }
    }


    resolved match {
      case Some(resolvent) => {
        if (resolvent.isEmpty) {
          log.debug("EMPTY CLAUSE RESOLVED FROM %s and %s", a, b)
          Some(EmptyClause())
        } else {
          log.debug("Resolved %s , from Clause %s,%s", resolvent, a, b)
          // do backsubstitution
          Some(resolvent)
        }
      }

      case None => {
        log.debug("NOTHING Resolved from Clause %s,%s", a, b)
        None
      }
    }

  }

}
