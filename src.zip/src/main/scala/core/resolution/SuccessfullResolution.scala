package core.resolution


import collection.immutable.Set
import containers.ClauseStorage
import domain.fol.ast.FOLClause

/**
 * User: nowi
 * Date: 18.03.2010
 * Time: 11:44:14
 */

sealed trait ResolutionResult {
  def contains(clause : FOLClause) : Boolean
  def size : Int
  def resolvents : Set[FOLClause]
}

sealed trait ReductionResult {
  def contains(clause : FOLClause) : Boolean
  def size : Int
  def resolvents : Set[FOLClause]
}


case class SuccessfullResolution(override val resolvents : Set[FOLClause],val parent1:FOLClause,val parent2:FOLClause) extends ResolutionResult {
  override def contains(clause: FOLClause) = resolvents.contains(clause)
  override def size = resolvents.size
}

object SuccessfullResolution {
  def apply(clauseStorage : ClauseStorage,parent1:FOLClause,parent2:FOLClause) : SuccessfullResolution = {
    SuccessfullResolution(clauseStorage.values,parent1,parent2)
  }
}

case class FailedResolution(val parent1:FOLClause,val parent2:Option[FOLClause]) extends ResolutionResult {
  override val resolvents = Set[FOLClause]()
  override  def contains(clause: FOLClause) = false

  override def size = 0
}


case class SuccessfullReduction(override val resolvents : Set[FOLClause],val parent1:FOLClause,val parent2:FOLClause) extends ReductionResult {
  override def contains(clause: FOLClause) = resolvents.contains(clause)
  override def size = resolvents.size
}

object SuccessfullReduction {
  def apply(clauseStorage : ClauseStorage,parent1:FOLClause,parent2:FOLClause) : SuccessfullReduction = {
    SuccessfullReduction(clauseStorage.values,parent1,parent2)
  }
}

case class FailedReduction(val parent1:FOLClause,val parent2:Option[FOLClause]) extends ReductionResult {
  override val resolvents = Set[FOLClause]()
  override  def contains(clause: FOLClause) = false
  override def size = 0
}

