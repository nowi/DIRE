package core;


/**
 * User: nowi
 * Date: 04.02.2010
 * Time: 17:35:00
 */
public enum ProvingResult {
    COMPLETION,PROOF,TIMEUP;
}
