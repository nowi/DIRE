package kernel.dispatching


import allocation.ClauseAllocation
import collection.immutable.HashMap
import core.containers.{CNFClauseStore, NonEmptyClauseStore, ClauseStorage}
import core.resolution.UniqueLiteralResolution
import domain.fol.ast.FOLClause
import se.scalablesolutions.akka.actor.{ActorRegistry, Actor}
import se.scalablesolutions.akka.dispatch.Dispatchers

/**
 * User: nowi
 * Date: 09.02.2010
 * Time: 10:36:18
 */

/**
 * Sends clauses accoring to Distributed Resolution Rules
 */
class DALCDispatcherActor(env: {val uniqueLiteralResolver: UniqueLiteralResolution})
        extends DispatchingActor {

  val uniqueLiteralResolver = env.uniqueLiteralResolver







  override def determineDestination(clauses: Iterable[FOLClause], allocation: ClauseAllocation) = {
    //record.trace("Reasoner: %s  clauses %s to reasoners : ", this, clauses,reasoners)
    // get the unique resolvable literal of this clause

    // TODO add short circuit here if locally responsible ... ?

    val reasoners = ActorRegistry.actorsFor("kernel.DALCReasoner")
    // create dispatching mapping

    var mapping : Map[Actor, FOLClause]= new HashMap[Actor, FOLClause]()

    // check the URLit of each clPOm.xmlause
    for (clause <- clauses) {
      // get the reasoner that is responsible for this clause

      // get the urlit
      clause.uniqueResolvableLit(uniqueLiteralResolver) match {
        case Some(urLit) => {

          // TODO hack until i get the latest akka buidling
          ActorRegistry.actorFor(allocation(urLit.symbolicName)) match {
            case Some(actor)if(actor != parent.get) => {
              mapping = Map[Actor, FOLClause](actor -> clause) ++ mapping // found one actor OK!
            }
            case Some(actor)if(actor == parent.get) => {
              log.debug("ignoring this clause stays here !")
            }
            case None => error("No actor found for this symbol , cannot dispatch derived clause !")
          }
          
//          ActorRegistry.actorsFor(allocation(urLit.symbolicName)) match {
//            case Nil => error("No actor for this id , this should not happpen !")
//            case actor :: List() => mapping = Map[Actor, FOLClause](actor -> clause) ++ mapping // found one actor OK!
//            case actor :: moreActors => error("Multiple actors registered for this unique resolvable lit ... should not happen")
//          }
        }
        case None => {
          // no unique resolvable literal -- we do not send this
          log.debug("No unique resolvable literal for clause %s .. we do not dispatch!",clause)

        }
      }


    }

    // bundle all clauses that go to same reasoner into one clausestore
    if(mapping.size > 0)
      mapping.map({case (actor, clauses) => Map(actor -> CNFClauseStore(clauses))}).reduceLeft(_ ++ _)
    else
      Map()

  }

}