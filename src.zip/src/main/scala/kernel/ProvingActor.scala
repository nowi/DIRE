package kernel


import collection.mutable.ArrayBuffer
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy
import java.util.Date
import se.scalablesolutions.akka.dispatch.Dispatchers
import core._
import containers.{NonEmptyClauseStore, ClauseStorage, CNFClauseStore}
import domain.fol.ast.FOLClause
import domain.fol.parsers.SPASSIntermediateFormatParser
import helpers.Subject
import java.io.File
import core.reduction._
import core.rewriting.{Substitutor, VariableRewriter}
import ordering.{CustomConferencePartitionedPrecedence, CustomSPASSModule1Precedence, ALCLPOComparator}
import ProvingState._
import ProvingResult._
import core.selection.NegativeLiteralsSelection
import resolution.{Success, OrderedResolver}
import se.scalablesolutions.akka.actor.Actor
import se.scalablesolutions.akka.util.Logging
import sun.reflect.generics.reflectiveObjects.NotImplementedException

/**
 * User: nowi
 * Date: 03.02.2010
 * Time: 17:11:44
 */

abstract class ProvingActor extends Actor with ReasoningActorChild {


  // cofigure a native os thread based dispatcher for the proving actor
  val d = Dispatchers.newThreadBasedDispatcher(this)

  messageDispatcher = d

  val prover: FOLProving


  var state: ProvingState = STOPPED

  var initialClauses: ClauseStorage = CNFClauseStore()
  var keptClauses: ClauseStorage = CNFClauseStore()

  var incomingClausesLog: ArrayBuffer[Tuple3[Date, Actor, ClauseStorage]] = new ArrayBuffer


  private[this] def setState(newState: ProvingState) {
    log.info("%s transitions from %s to %s state", this, state, newState)
    state = newState
    // inform supervisor rsabout state change
    parent.get ! ProverStatus(state)


  }


  /**
   * Callback from proving alogorithm
   *
   */
  def receiveUpdate(resolutionResult: Any) {
    //println("Recieved derived clauses , sending them to dispatcher actor")
    // send derived clauses to clause dispatcher
    parent match {
      case Some(parentActor) => {
        resolutionResult match {
          case result : SuccessfullResolution => {
          // pass the derived clauses to the parent actor
          parentActor ! (Derived(result), this)
          
        }
          case _ => throw new IllegalArgumentException("Callback can only process ClauseStores")
        }
      }

      case None => throw new IllegalStateException("Proving Actor needs a parent actor")
    }


  }


  def doSaturate(sender: Actor) {
    setState(SATURATING);
    val result = prover.saturate(initialClauses, keptClauses)
    // finished saturatign

    result match {
      case (COMPLETION, clauses: ClauseStorage) => {
        // save the kept clauses
        log.info("LOCALY SATISFIED ... ")
        keptClauses = clauses
        // clear the initial clauses
        initialClauses = CNFClauseStore()
        setState(SATISFIABLE)
      }
      case (PROOF, clauses: ClauseStorage) => {
        log.info("LOCALY UNSATISFIED ! ")
        // clear the initial clauses
        initialClauses = CNFClauseStore()
        setState(UNSATISFIABLE)
      }

      case (TIMEUP, clauses: ClauseStorage) => {
        log.info("TIMELIMIT REACHED ! ")
        keptClauses = clauses
        // clear the initial clauses
        initialClauses = CNFClauseStore()
        setState(SATISFIABLE)
      }

    }
  }

  protected def receive = {
    case (Entail(clauses), sender: Actor) => {

      // first check the state
      state match {
        case SATISFIABLE => {
          // the kb is satisfiable, we can resume prooving with the keptclauses , and add the recieved clause
          initialClauses = clauses ::: initialClauses
          doSaturate(sender)
        }
        case _ => {
          // drop the recived clause
          error("Dropping recieved clauses , we should really not do this ! , claues were : %s" format (clauses))

        }
      }

    }


    case msg @ GetStatus(bla) => {
      log.debug("Recieved Status Request Message")
      reply(Status("Status : %s" format (state)))


    }



    case (LoadClauses(clauses), sender: Actor) => {
      log.trace("%s Recieved Load Message with clauses to load %s", this, clauses)
      if (state == STOPPED) {
        initialClauses = clauses;
        setState(LOADED)
      } else {
        throw new IllegalStateException("Cannot load initial clauses while in state : %s" format (state))
      }

    }

    case GetKeptClauses(bla) => {
      log.info("Recieved GetKeptClauses Request Message")
      state match {
        case SATISFIABLE => reply(KeptClauses(keptClauses))
        case _ => {
          log.warning("KeptCLauses have been requested but prover is not in state SATISFIABLE")
          reply(KeptClauses(keptClauses))
        }
      }

    }


    case msg @ GetIncomingClausesLog(bla) => {
      log.trace("Recieved GetKeptClauses Request Message")

      reply(incomingClausesLog)

    }


    case (StartSatisfy(message), sender: Actor) => {
      log.trace("%s Recieved StartSatisfy Message", this)

      state match {
        case LOADED | SATISFIABLE | UNSATISFIABLE => {
          doSaturate(sender)

          // reply the current status to the original sender of the message
          reply(ProverStatus(state))

        }
        case _ => {
          log.error("Cannot load initial clauses while in state : %s" format (state))
          throw new IllegalStateException("Cannot load initial clauses while in state : %s" format (state))
        }
      }


    }

    case (StopSatisfy(message), sender: Actor) =>
      log.trace("%s Recieved StopStatisfy Message", this)
  }

  override def shutdown = {
    log.info("Core prooving subsystem is shutting down...")
  }

}






