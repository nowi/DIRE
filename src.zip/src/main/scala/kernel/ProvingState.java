package kernel;

/**
 * User: nowi
 * Date: 05.02.2010
 * Time: 16:36:18
 */
public enum ProvingState {
    STOPPED,LOADED,SATURATING,SATISFIABLE,UNSATISFIABLE;
}
