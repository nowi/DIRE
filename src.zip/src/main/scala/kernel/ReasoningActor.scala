package kernel

import collection.mutable.ArrayBuffer
import core.containers.{CNFClauseStore, ClauseStorage}
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy
import java.util.Date
import ProvingState._
import se.scalablesolutions.akka.actor.Actor
import se.scalablesolutions.akka.config.OneForOneStrategy
import se.scalablesolutions.akka.dispatch.Dispatchers

/**
 * The Main reasoning actor
 * User: nowi
 * Date: 22.01.2010
 * Time: 15:43:22
 */

abstract class ReasoningActor extends Actor {
  // configuration of core reasoning components

  id = this.uuid

  faultHandler = Some(OneForOneStrategy(5, 5000))
  trapExit = List(classOf[Exception])

  var incomingClausesLog: ArrayBuffer[Tuple3[Date, Actor, ClauseStorage]] = new ArrayBuffer



   // child prooving actor
  val provingActor : ProvingActor
  // child dispatcher  actor
  val dispatcherActor : DispatchingActor

  // child derivations logging  actor
  val derivationsLoggingActor : LoggingActor

  // child reductions logging  actor
  val reductionsLoggingActor : LoggingActor





  var proverStatus: ProvingState = STOPPED


  // abstract methods to be defined somewhere else
  protected def receive = {
     case msg @ LoadClauses(clauses) => {
      // forward to loggers
       derivationsLoggingActor ! (LoadClauses(clauses),this)

       // forward to loggers
       reductionsLoggingActor ! (LoadClauses(clauses),this)
      // send those clauses to the
      provingActor ! (msg,this)
    }



 case msg @ LoadAllocation(allocation) => {


   // forward to dispatcher
      dispatcherActor forward (msg,this)
    }


    case msg @ GetStatus(bla) => {
      log.info("Recieved Status Request Message")
      proverStatus match {
        case LOADED | SATISFIABLE | UNSATISFIABLE=> provingActor forward msg
        case _ => reply(Status("WORKING ! , Core proving subsystem status = " + proverStatus))
      }


    }

     case msg @ GetStatusOverride(bla) => {
      log.info("Recieved Status Overide Request Message.. forwarding to prover")
      provingActor forward GetStatus(bla)


    }


  case msg @ GetKeptClauses(bla) => {
    log.trace("Recieved GetKeptClauses Request Message")

    provingActor forward msg

    }

  case msg @ GetIncomingClausesLog(bla) => {
    log.trace("Recieved GetKeptClauses Request Message")

    reply(incomingClausesLog)

    }



     // INBOUND
    case msg @ (Entail(clauses),sender : Actor) => {
      log.debug("%s revieved Derived Clauses from sender %s .. clauses : %s",this,sender,clauses)
      // record the clause
      incomingClausesLog.append((new Date(System.currentTimeMillis), sender, clauses))


    }

     // OUTBOUND
     // handle dispatching of derived clauses
    case msg @ (Derived(result),sender : Actor) => {
      log.trace("Recieved Derived Message with derived clauses %s..from sender : %s forwarding to %s ",result, sender, dispatcherActor)
      // forward to logger
      derivationsLoggingActor forward (Derived(result),this)
      // forward to dispatcher
      // replace sender
      dispatcherActor forward (Derived(result),this)
    }


     case msg @ (Reduced(result),sender : Actor) => {
      log.trace("Recieved Reduced Message with derived clauses %s..from sender : %s forwarding to %s ",result, sender, dispatcherActor)
      // forward to logger
      reductionsLoggingActor forward (Derived(result),this)
      // we dont forward reduced clauses
      dispatcherActor forward (Derived(result),this)
    }                           


    // handle additional message type dispatching here !



    case msg @ StartSatisfy(message) => {
      // check state of prover
      proverStatus match {
        case LOADED | SATISFIABLE | UNSATISFIABLE => {
           log.trace("Recieved StartSatisfy Message.. forwarding to %s" , provingActor)
           provingActor ! (msg,this)
        }
        case _ => {
           log.trace("Recieved StartSatisfy Message.. forwarding to %s" , provingActor)
          provingActor ! (msg,this)
        }
      }

    }

    case msg @ StopSatisfy(message) => {
      log.debug("Recieved StopStatisfy Message .. forwarding to %s", provingActor)
      // forward to proover
      provingActor ! (msg,this)

    }


    // communiucation with prover kernel , prover kernel tells its status
    case msg @ ProverStatus(status) => {
      log.debug("Recieved ProverStatus Update Message.. new status of proover %s is %s", provingActor, status)
      log.debug("Recieved ProverStatus Update Message.. new status of proover ")
      // update the status of the prover
      proverStatus = status
      log.info("%s recived new core proover status: %s",this,proverStatus)

      proverStatus match {
        case LOADED | SATISFIABLE | UNSATISFIABLE => {
          incomingClausesLog match {
            case buffer if(buffer.isEmpty) => {

            }
            case _ => {

              // check if we have a backlog of new clauss for the prover
              // check if we have recieved new clauses in the mean time

              // we have recieved some clauses -- add them
              // extract from record
              val newClauses : ClauseStorage = incomingClausesLog.map(_._3).toList.reduceLeft(_ ::: _)
              log.info("%s has clause backlog, passing them to prooving actor : %s",this,newClauses)

              // clear the clause record
              incomingClausesLog.clear
              provingActor.!((Entail(newClauses),this))

            }
          }

        }
        case _ => {

          // reasoner is busy , cannot pass him the new clauses now
        }

      }



    }
  }





  override def init = {
    log.info("DALCReasoning actor is starting up and .. starting and linking %s and %s ",dispatcherActor,provingActor)
      dispatcherActor.start
      provingActor.start
      derivationsLoggingActor.start

    startLink(derivationsLoggingActor)
    startLink(dispatcherActor)
    dispatcherActor.link(Some(this))
    startLink(provingActor)
    provingActor.link(Some(this))
  }

  override def shutdown = {
    log.info("DALCReasoningNode server is shutting down...")
    unlink(derivationsLoggingActor)
    unlink(dispatcherActor)
    unlink(provingActor)
  }
  // outbox actor

  // inbox actor



}

