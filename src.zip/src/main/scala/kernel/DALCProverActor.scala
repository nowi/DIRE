package kernel

import dispatching.{BroadCastDispatchingActor, ToVoidDispatchingActor, DALCDispatcherActor}
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy
import se.scalablesolutions.akka.dispatch.Dispatchers
import core._
import config.DALCConfig
import containers.{NonEmptyClauseStore, ClauseStorage, CNFClauseStore}
import domain.fol.ast.FOLClause
import domain.fol.parsers.SPASSIntermediateFormatParser
import helpers.Subject
import java.io.File
import core.reduction._
import core.rewriting.{Substitutor, VariableRewriter}
import ordering.{CustomConferencePartitionedPrecedence, LexicographicPrecedence, CustomSPASSModule1Precedence, ALCLPOComparator}
import ProvingState._
import ProvingResult._
import resolution.{DALCUniqueLiteralResolver, DALCResolver, OrderedResolver}
import se.scalablesolutions.akka.actor.Actor
import se.scalablesolutions.akka.util.Logging
import selection.{DALCRSelector, NegativeLiteralsSelection}
import sun.reflect.generics.reflectiveObjects.NotImplementedException

/**
 * User: nowi
 * Date: 02.03.2010
 * Time: 12:34:38
 */

trait Neo4JLoggingActorFactory {
  this: ReasoningActor =>
  // create the dispatcher actor
  val loggingActor = new Neo4JLoggingActor(DALCConfig)
}

trait DALCDispatcherActorFactory {
  this: ReasoningActor =>
  // create the dispatcher actor
  val dispatcherActor  = new DALCDispatcherActor(DALCConfig)
}

trait ToVoidDispatcherActorFactory {
  this: ReasoningActor =>
  // create the dispatcher actor
  val dispatcherActor = new ToVoidDispatchingActor
}

trait BroadCastDispatcherActorFactory {
  this: ReasoningActor =>
  // create the dispatcher actor
  val dispatcherActor = new BroadCastDispatchingActor
}

trait DALCProverActorFactory {
  this: ReasoningActor =>
  // configure the core prover
  val provingActor = new ProvingActor with CoreResolutionProver1Factory



}



trait CoreResolutionProver1Factory {
  this: ProvingActor =>
  // configure the core prover
  val prover = new ResolutionProover1(DALCConfig)
  // setup this actor as a listener for resolution events
  prover.addObserver(this)


}




case class DALCReasoner extends ReasoningActor with DALCProverActorFactory with DALCDispatcherActorFactory with Neo4JLoggingActorFactory

case class DALCReasonerNoDispatch extends ReasoningActor with DALCProverActorFactory with ToVoidDispatcherActorFactory with Neo4JLoggingActorFactory

//case class DALCReasonerBroadCastDispatch extends ReasoningActor with DALCProverActorFactory with BroadCastDispatcherActorFactory










