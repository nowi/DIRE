package kernel

import se.scalablesolutions.akka.actor.Actor

/**
 * User: nowi
 * Date: 22.01.2010
 * Time: 18:37:41
 */
class ReasoningTestClient(val name: String, reasoners: List[Actor]) {
  

}



