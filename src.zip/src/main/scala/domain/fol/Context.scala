package domain.fol


import ast.{FOLNode, Variable}
import collection.MapProxy

/**
 * User: nowi
 * Date: 01.04.2010
 * Time: 16:15:12
 */

class Context extends MapProxy[Variable,FOLNode] {

  this(map : Map[Variable,FOLNode]) = Map(map)

  def bind(variable : Variable,term : FOLNode) : Context  = {
    this + (variable -> term)
  }


  override def apply(key: Variable) = {
    get(key)

  }
}

object Context {
  def apply() : Context = new Context
  def apply(map : Map[Variable,FOLNode]) : Context = new Context(map)
}