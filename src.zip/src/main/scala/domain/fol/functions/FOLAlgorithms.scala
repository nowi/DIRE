package domain.fol.functions


import ast.{Complex, Variable, FOLNode}
import collection.mutable.Stack

/**
 * User: nowi
 * Date: 01.04.2010
 * Time: 16:09:37
 */

object FOLAlgorithms {
  def unify(term1 : FOLNode,term2 : FOLNode) : Option[Substitution] = {
    var unifies = true;

    var dopop = false

    var s = term1
    var t = term2
    var cS = Context()
    var cT = Context()

    // initialize a mutable stack
    val stack = new Stack[(FOLNode,Context)]()


    do {
      if(dopop){
        dopop = true
        (s,cS) = stack.pop
        (t,cT) = stack.pop
      }

        (s,t) match {
          case (Complex(sTerms),Complex(tTerms))if(s.symbolicName == t.symbolicName) => {
            // push all terms onto the stack
            sTerms.foreach(stack.push(_,cS))
            tTerms.foreach(stack.push(_,cT))

            s = sTerms.head
            t = tTerms.head

            // continue
            dopop = false

          }

          case (variable : Variable,_) => {
            if(occurCheck(s,t,cS,cT)) {
              unifies = false
              stack.clear
            } else {
              cS = cS.bind(variable,t)
            }

          }

          case (_,variable : Variable) => {
            if(occurCheck(t,s,cT,cS)) {
              unifies = false
              stack.clear
            } else {
              cT = cT.bind(variable,s)
            }

          }

          case _ => {
            unifies = false
            stack.clear
          }

        }

    } while(!stack.isEmpty)

    if(unifies) {
      val subs = (cT ++ cS).foldLeft(Substitution())(_ ++ _)// merge the contexts -->
      Some(subs)
    } else None

  }



  def matcher(term1 : FOLNode,term2 : FOLNode) : Option[Substitution] = {
    var t = term1
    var s = term2
    var context : Context = Context()

    var matches = true

    // initialize a mutable stack
    val stack = new Stack[FOLNode]()

    var dopop = false

    do {


       if(dopop){
        dopop = true
        s = stack.pop
        t = stack.pop
      }


      (s,t) match {
        case (Complex(sArgs),Complex(tArgs)) if(s.symbolicName == t.symbolicName) => {
          sArgs.foreach(stack.push _ )
          tArgs.foreach(stack.push _ )

          s = sArgs.head
          t = tArgs.head

          dopop = false

        }

        case (s : Variable, _ ) => {
          if(!context(s).isDefined) {
            context = context + (s -> t)
          } else if(context(s) != t) {
            matches = false
            stack.clear
          }

        }

        case _ => {
          matches = false
          stack.clear

        }


      }


    } while(!stack.isEmpty)



    if(matches) {
      // create the matcher from the context
      val subs = context.foldLeft(Substitution())(_ ++ _)// merge the contexts -->
      Some(subs)
    } else {
      None
    }



  }



}