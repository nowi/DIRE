package domain.fol.ast

/**
 * User: nowi
 * Date: 25.09.2009
 * Time: 17:22:33
 */

trait NamedObject {
  def name: String
}