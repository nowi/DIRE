package domain.fol.ast

/**
 * User: nowi
 * Date: 25.09.2009
 * Time: 16:15:51
 */

abstract class Expr