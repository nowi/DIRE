package domain.fol.ast

import parsers.SPASSIntermediateFormatParser._

import core.ordering.LiteralComparison
import core.resolution.UniqueLiteralResolution

trait FOLClause {
  // all folnodes have to be literals
  val literals: Set[FOLNode]


  def ++(that: FOLClause): FOLClause


  def --(that: FOLClause): FOLClause


  def -(that: FOLNode): FOLClause

  def +(that: FOLNode): FOLClause

  def absoluteClause: FOLClause

  lazy val size: Int = literals.size


  lazy val uniqueResolvableLit = {
    // only if its clear which resolver has been used to determine the
    // urlit
    require(uniqueLits.size == 1)
    uniqueLits.values.next
  }

  // maximal literal cache comperator --> maxLiterals
  protected var maxLiterals: Map[LiteralComparison, List[FOLNode]] = Map[LiteralComparison, List[FOLNode]]()

  // unique resolvable literal cache
  protected var uniqueLits: Map[UniqueLiteralResolution, Option[FOLNode]] = Map[UniqueLiteralResolution, Option[FOLNode]]()


  def uniqueResolvableLit(resolver: UniqueLiteralResolution): Option[FOLNode] = {
    val urlit = resolver.determineURLit(this)
    // cache this this max lit
    uniqueLits += (resolver -> urlit)
    urlit
  }


  def maxLits(comperator: LiteralComparison): List[FOLNode] = {
    assert(!isEmpty, "There cannot be a max Lit in Empty Clause")
    // do lookup
    maxLiterals.get(comperator) match {
      case Some(lit) => lit
      case None => {
        // we have no max for this comparator , determine the max and cache it
        var maximumLiterals: List[FOLNode] = List(literals.toList.head)

        val iter = literals.elements
        while (iter.hasNext) {
          val lit = iter.next
          val max = maximumLiterals.head
          if (lit != max) {
            comperator.compare(lit, maximumLiterals.head) match {
              case Some(1) => maximumLiterals = List(lit) // found a greater lit , this is new maxLit
              case Some(0) => maximumLiterals = lit :: maximumLiterals // found same as current max , add to maxlits
              case Some(-1) => None
              case None => {
                None
              }
            }

          }

        }

        // make maximum litera

        // cache this this max lit
        maxLiterals += (comperator -> maximumLiterals)
        maximumLiterals
      }

    }

  }


  lazy val absoluteLiterals: Set[FOLNode] = {
    literals map (_ match {
      case Negation(filler) => filler
      case x: FOLNode => x

    })

  }

  lazy val positiveLiterals: Set[FOLNode] = {
    literals filter (_ match {
      case PositiveFOLLiteral(_) => true
      case _ => false

    })

  }
  lazy val negativeLiterals: Set[FOLNode] = {
    (literals filter (_ match {
      case NegativeFOLLiteral(_) => true
      case _ => false

    }))

  }


  lazy val signature = {
    literals.map({
      x: FOLNode => x match {
        case PositiveFOLLiteral(literal) => (literal.symbolicName, literal.arity)
        case NegativeFOLLiteral(literal) => ("-" + literal.symbolicName, literal.arity)
      }

    })

  }


  /**Retrieve the literals which is associated with the given literal signature.
   * @param litSig the signature of the literal (symblicname,arity)
   * @return the literals
   */
  def apply(litSig: (String, Int)): Set[FOLNode] = {
    literals.map({
      x: FOLNode => x match {
        case PositiveFOLLiteral(literal) if (litSig == (literal.symbolicName, literal.arity)) => x
        case NegativeFOLLiteral(literal) if (litSig == ("-" + literal.symbolicName, literal.arity)) => x
      }

    })

  }


  lazy val isEmpty = literals.isEmpty

  lazy val isUnit = literals.size == 1

  // A Horn clause is a disjunction of literals of which at most one is
  // positive.
  lazy val isHorn = !isEmpty && positiveLiterals.size <= 1

  lazy val isDefinitive = !isEmpty && positiveLiterals.size == 1

}

/**
 * User: nowi
 * Date: 07.10.2009
 * Time: 15:54:46
 *
 * A standard clause == disjunction of literals == Literal OR Literal ...
 */
case class StandardClause(literals: Set[FOLNode]) extends FOLClause {
  // all folnodes have to be literals
  assert(literals forall ((_ match {
    case FOLLiteral(x) => true
    case _ => false
  })), "FOL nodes passed into a clause can only be Literals, but literals were : %s" format (literals))

  // copy  constructor
  def this(clause : FOLClause) = this(clause.literals)



  override def ++(that: FOLClause): FOLClause =
    StandardClause(literals ++ that.literals)


  override def --(that: FOLClause): FOLClause =
    StandardClause(literals -- that.literals)


  override def -(that: FOLNode): FOLClause =
    StandardClause(literals - that)


  override def +(that: FOLNode): FOLClause =
    StandardClause(literals + that)


  override def absoluteClause = StandardClause(absoluteLiterals)


  override def toString = {
    val litStrings = literals.map({
      _ match {
        case x if (maxLiterals.values.contains(x)) => x.toString + "*"
        case x => x.toString
      }
    })
    "%s" format (litStrings mkString ("[", "V", "]"))
  }


}

case class ALCDClause(override val literals: Set[FOLNode]) extends StandardClause(literals) {
  // some more assertions
// all folnodes have to be literals
  assert(literals forall ((_ match {
    case NestedFunctionLiteral(x)  => false
    case NestedPredicateLiteral(x)  => false
    case _ => true
  })), "FOL function or predicate literals passed into a ACLDFOL cannot be nested, but literals were : %s" format (literals))

 // copy  constructor
  def this(clause : FOLClause) = this(clause.literals)

}

object ALCDClause {
  def apply(params: FOLNode*): ALCDClause = {
    ALCDClause(Set(params: _*))
  }

  def apply(clause: FOLClause): ALCDClause = {
    new ALCDClause(clause)
  }

  // string based constructor using tha parser
  


  //implicit def FOLClauseToStandardClause(x: FOLClause): StandardClause = x.asInstanceOf[StandardClause]

}


case class EmptyClause extends FOLClause {
  override val literals = Set[FOLNode]()

  override def toString = "■"

  override lazy val isEmpty = true


  override def absoluteClause = EmptyClause()

  override def +(that: FOLNode) = EmptyClause()

  override def -(that: FOLNode) = EmptyClause()

  override def ++(that: FOLClause) = EmptyClause()

  override def --(that: FOLClause) = EmptyClause()
}

object StandardClause {
  def apply(params: FOLNode*): StandardClause = {
    StandardClause(Set(params: _*))
  }





  implicit def FOLClauseToStandardClause(x: FOLClause): StandardClause = x.asInstanceOf[StandardClause]

}


