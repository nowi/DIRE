package domain.fol


import ast.{Term, Variable, FOLNode}
import collection.MapProxy

/**
 * User: nowi
 * Date: 01.04.2010
 * Time: 13:24:29
 */

case class Substitution extends MapProxy[Variable,FOLNode]{
  def domain : Set[Variable] = keys
  def codomain : Set[FOLNode] = values
  def image : Set[Variable] = {
    codomain.map(_.flatArgs.filter({
      _ match {
        case Variable(x) => true
        case _ => false
      }
    }))
  }




  /** Add a sequence of key/value pairs to this map.
   *  @param    kvs the iterable object containing all key/value pairs.
   *  @return   A new map with the new bindings added
   */
  override def apply(variable: Variable) = {
    get(variable) match {
      case Some(term) => term
      case None => variable
    }
  }


  // composition , p21 Term Indexing , Peter Graph
  override def ++(that: Substitution) : Substitution= {
    // the images of both substitions might be affected by the substitions
    // first apply the substititons to the images
    (this map({case(variable,term) => (variable -> that(variable))}))
    ++ (that.domain -- this.domain)
  }

  // join
  def **(that: Substitution) : Substitution = {
    (this map({case(variable,term) => (variable -> that(variable))}))
    ++ (that.domain -- this.image)

  }
}

object Substitution {
  val generalizations = (s1: Substitution, s2: Substitution) => {
    val ms: Set[Option[Substitution]] = s1.domain.map({
      x: Variable => matcher((s1 ** s2).apply(x), s2(x))
    }).foldLeft(Set())(_ ++ _)
    require(ms.forall(_.isDefined)) // all defined == not "None"
    require(ms.size == 1) // all the same
    ms.head
  }

  val unifiers = (s1: Substitution, s2: Substitution) => {
    val us: List[Option[Substitution]] = s1.domain.map({
      x: Variable => unify((s1 ** s2).apply(x), s2(x))
    })
    require(us.forall(_.isDefined)) // all defined
    require(us.size == 1) // all the same
    us.head

  }


  val mscg = (s1: Substitution, s2: Substitution)





  implicit def iterableToSubs(iter: Iterable[Tuple2[Variable,FOLNode]]): Substitution = {
    iter.asInstanceOf[Substitution]
  }


  implicit def tupleToSubs(tuple: Tuple2[Variable,FOLNode]): Substitution = {
      tuple.asInstanceOf[Substitution]

  }



}