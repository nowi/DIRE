package helpers


import se.scalablesolutions.akka.util.Logging

/**
 * User: nowi
 * Date: 10.11.2009
 * Time: 13:57:53
 */

trait Logging extends se.scalablesolutions.akka.util.Logging{
}