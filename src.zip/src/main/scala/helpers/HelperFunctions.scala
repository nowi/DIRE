package helpers

/**
 * User: nowi
 * Date: 03.04.2010
 * Time: 13:49:36
 */

object HelperFunctions {


}