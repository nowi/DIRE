package domain.fol.ast

/**
 * User: nowi
 * Date: 31.03.2010
 * Time: 15:50:15
 */

case class Binding extends Tuple2[Variable,Term] {

}