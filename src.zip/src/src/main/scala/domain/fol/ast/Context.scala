package domain.fol.ast


import collection.MapProxy

/**
 * User: nowi
 * Date: 31.03.2010
 * Time: 16:56:28
 */

trait Context extends MapProxy[Variable,Term] {
  def bind(variable : Variable , term : Term) : Context = this + (variable -> term)
  def binding(variable : Variable) : Term = this(variable)
}