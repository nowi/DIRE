package core.index


import collection.mutable.Stack
import domain.fol.ast.{FOLNode, Variable}
import domain.fol.functions.FOLAlgorithms._
import domain.fol.Substitution

/**
 * User: nowi
 * Date: 31.03.2010
 * Time: 20:38:23
 */


object SubstitutionFunctions {
}



abstract class SubstitutionIndexTree {
  def convertIterableOfOptions(iter: Iterable[Option[Substitution]]) = {
    if (iter.forall(_ isDefined)) {
      Some(iter.map(_.get))
    } else None
  }


  /**
   * The test function 'generalization' checks for every assignment of the substitution s1
   * if under the current variable bindings denoted by s2 , a Simultaneous matcher m from all
   * terms of the codomain to the correspoding bindings of the domain variables exists
   */
  val generalizations = (s1: Substitution, s2: Substitution) => {
    val ms: Set[Option[Substitution]] = s1.domain.map({
      x: Variable => matcher((s1 ** s2).apply(x), s2(x))
    }).foldLeft(Set())(_ ++ _)

    // convert
    convertIterableOfOptions(ms) match {
      case Some(head :: Set()) => {
        // only one element , looks right
        head
      }

      case _ => {
        error("Error in finding simulatanous matcher")
      }
    }

  }

  val unifiers = (s1: Substitution, s2: Substitution) => {
    val us: List[Option[Substitution]] = s1.domain.map({
      x: Variable => unify((s1 ** s2).apply(x), s2(x))
    })

    // convert
    convertIterableOfOptions(us) match {
      case Some(head :: Set()) => {
        // only one element , looks right
        head
      }

      case _ => {
        error("Error in finding simulatanous unfier")
      }
    }

  }


  val instances = (s1: Substitution, s2: Substitution) => {
    unifiers(s1, s2) match {
      case Some(unifier) => {
        // the intersection of unifier and (domain(unfier) ++ indicator variables, has to be empty
        // in other words , the unifers domain cannot contain a indicator variable
        unifier.domain.forall(!_.instanceOf[IndicatorVariable]) match {
          case true => unifier
          case false => None
        }

      }

      case None => None // there has been no unfier to begin with
    }
  }

  val variants = (s1: Substitution, s2: Substitution) => {
    generalizations(s1, s2) match {
      case Some(matcher) => {
        // the intersection of matcher and (domain(matcher) ++ indicator variables, has to be empty
        // in other words , the matcher domain cannot contain a indicator variable
        matcher.domain.forall(!_.instanceOf[IndicatorVariable]) match {
          case true => matcher
          case false => None
        }

      }

      case None => None // there has been no unfier to begin with
    }
  }





  val testUnification = (tree: SubstitutionIndexTree, stack: Stack[Tuple2[Variable, FOLNode]]) => {
    unifiers(tree.substitution, stack) match {
      case Some(unifier) => {
        for (binding <- unifier)
          stack.push(binding)
        unifier.size
      }
      case None => {
        0
      }

    }

  }

  val testGeneralization = (tree: SubstitutionIndexTree, stack: Stack[Tuple2[Variable, FOLNode]]) => {
    generalizations(tree.substitution, stack) match {
      case Some(matcher) => {
        for (binding <- matcher)
          stack.push(binding)
        matcher.size
      }
      case None => {
        0
      }

    }

  }

  val insert = (tree: SubstitutionIndexTree, p: Substitution, openVariables: Set[Variable]) => {

    (tree, p, openVariables) match {
      case (EmptyTree, p, ovs) => {
        // rule 6.14 p173 Term Indexing - Peter Graf ( LNCS 1053 )
        // a new leaf node is created
        // normalize p
        LeafNode(p)


      }

      case (LeafNode(leafNode), p, ovs) => {
        // rule 6.15 -- An existing leaf node is returned if p corresponds to a variant
        // substitution which has already been inserted



      }

      // inner nodes :

      case (InnerNode(innerNode), p, ovs) => {
        // 6.16 -- If a variant node is found, a subnode of the current node is selected
        // for continued insertion by the heuristic

      }

      case (InnerNode(innerNode), p, ovs) => {
        // 6.17 -- If the heuristic return the empty subnode for insertion, a new leaf node
        // is created

      }

      case (InnerNode(innerNode), p, ovs) => {
        // 6.18 -- a new inner node and a new leaf are created in case the substitution in
        // the tree is not a variant of p. In this case the set of open variables ovs is needed
        // for completely describing the inserted substitution at the new leaf node.

      }


    }

    // TODO -- as the index is used as a means to accessing data, it should be possible to
    // store additional information at the leaf nodes of the tree. Therefore, in an implementation
    // of insert it is reasonable to return the found or created leaf node, such that the
    // user can perform additional operations.


  }




  // substition saved in the current node
  val substitution: Option[Substitution]

  val trees: Set[SubstitutionIndexTree]

  // substititutions savad in the substrees
  def substitutions: Set[Substitution] = {
    trees.map(_.substitutions).foldLeft(substitution)(_ ++ _)
  }









  /* standard retrieval
  The search in the index is started for a single substitution which in this context
  is called query. In contrast to the merge this is calles standard retrieval.

  Retrieval in Substitution trees is very simple. Generally, the retrieval algorithm checks each node of the tree for some special conditions. If the conditions are fulfilled the algorithm proceeds with the subnodes of the node that has been successfully tested. On its way down to the leaf nodes of the tree, the set of passed nodes is collected.
  There are three different tests which have to be performed:
  Find more general sub- stitutions, compatible substitutions, and instances.
  The functions Q, 1, and U Support the tests at the nodes of the tree.
  For each assignment Xi i-> U of the current node's Substitution the functions test whether the variable Xi or whatever it is
  bound to is more general, an instance of, or unifiable with t,-.
  Each of these functions can be used as a Parameter for the retrieval function	search.
  */

  def search(bindingStack: scala.collection.mutable.Stack[Tuple2[Variable, FOLNode]], testFunction: (SubstitutionIndexTree, Stack[Tuple2[Variable, FOLNode]] => Int)) = {
    var hits: List[SubstitutionIndexTree] = List()

    // get the bindings count
    val noBindings = testFunction(this, bindingStack)
    if (noBindings > 0) {
      hits = hits :: tree
      // descend into subtrees
      for (subTree <- tree.trees)
        hits = hits :: search(subTree, bindingStack, testFunction)
    }

    // backtrack
    for (i <- 0 until noBindings)
      bindingStack.pop

    hits

  }

  def get(k: K): Option[V]

  // insert: Insert a value at a key.
  def insert(k: K, v: V) = modifiedWith(k, (_, _) => Some(v))

  // remove: Delete a key.
  def remove(k: K) = modifiedWith(k, (_, _) => None)
}


case class EmptyTree extends SubstitutionIndexTree {
  override val trees = Set.empty
  override val substitution = None
}

// A leaf node.
case class LeafNode(override val substitution: Substitution) extends SubstitutionIndexTree {
  override val trees = Set.empty

}


// A inner node.
case class InnerNode(override val substitution: Substitution, override val trees: Set[SubstitutionIndexTree]) extends SubstitutionIndexTree {
}

//
//// A helper object.
//object GenericTree {
//
//  // empty: Converts an orderable type into an empty RBMap.
//  def empty[K <: Ordered[K], V] : GenericTree[K,V] = L()((k : K) => k)
//
//  // apply: Assumes an implicit conversion.
//  def apply[K, V](args : (K,V)*) : GenericTree[K,V] = {
//    var currentMap : GenericTree[K,V] = L()
//    for ((k,v) <- args) {
//      currentMap = currentMap.insert(k,v)
//    }
//    currentMap
//  }
//}
