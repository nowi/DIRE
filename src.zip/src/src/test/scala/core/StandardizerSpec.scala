package core

/**
 * User: nowi
 * Date: 25.09.2009
 * Time: 17:56:34
 */

import com.jteigen.scalatest.JUnit4Runner

import domain.fol.ast._
import org.junit.runner.RunWith


import org.scalatest.matchers.ShouldMatchers
import org.scalatest.Spec

import rewriting.VariableRewriter
import helpers.Logging

@RunWith(classOf[JUnit4Runner])
class StandardizerSpec extends Spec with ShouldMatchers with Logging{
  val config = new Object {
    val variableRewriter = new VariableRewriter()
  }

  val standardizer = new Standardizer(config)


  describe("The Standardizer") {
    it("should stardize (Knows(John,x), Know s(x, Elizabeth))") {
      val john = Constant("John")
      val jane = Constant("Jane")
      val leonid = Constant("Leonid")
      val elizabeth = Constant("Elizabeth")
      val a = Function("Knows", List(john, Variable("x")))
      val b = Function("Knows", List(john, jane))
      val c = Function("Knows", List(Variable("y"), leonid))
      val d = Function("Knows", List(Variable("y"), Function("Mother", List(Variable("y")))))
      val e = Function("Knows", List(Variable("x"), elizabeth)) // standardise apart


      // standardize a and e
      val (x, y,renamings) = standardizer.standardizeApart(a, e)
      (x, y) should not equal ((a, e))

    }

    it("should unify Clause  A = {¬P (z , a), ¬P (z , x), ¬P (x, z )} union B = {P (z , f (z )), P (z , a)}.  ") {
      val x = Variable("x")
      val a = Variable("a")
      val z = Variable("z")
      // A = {¬P (z , a), ¬P (z , x), ¬P (x, z )}
      val A = StandardClause(Negation(Predicate("P", z, a)), Negation(Predicate("P", z, x)), Negation(Predicate("P", x, z)))
      val B = StandardClause(Predicate("P", z, Function("f", z)), Predicate("P", z, a))


      val theta5 = standardizer.standardizeApart(A, B)

      log.trace("Standardized Apart tuple of clause A and B : %s is %s", A, theta5)
      theta5 should not equal ((A, B))

      // and there should be no vars in common



    }


  }


}
