//package core.resolution
//
///**
// * User: nowi
// * Date: 13.12.2009
// * Time: 14:38:22
// */
//import com.jteigen.scalatest.JUnit4Runner
//
//import config.WestOrderedTheoremProovingConfig
//import org.junit.runner.RunWith
//
//@RunWith(classOf[JUnit4Runner])
//class OrderedResolverWestDomainSpec extends ALCOrderedResolutionSpec {
//  override val resolver = new OrderedResolver(WestOrderedTheoremProovingConfig)
//
//}